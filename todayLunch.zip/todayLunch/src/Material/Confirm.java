package Material;

import JAVAJDBC.Material_Action;

public class Confirm extends javax.swing.JFrame {

    String message = null;
    String evtCommand = null;
    Object temp = null;
    
    
    Material_Action m_action;
    
    private static Confirm confirm;
    
    private Confirm(String message, String evtCommand, Object temp) {
        //���� getInstance������ �ٷ� �������� ����. �׷��� �������� �ͼ� �����ذŴ�.
        this.message = message;
        this.evtCommand = evtCommand;
        this.temp = temp;
        initComponents();
    }
    
    //�ش� �޼ҵ� �����Ű��
    public static Confirm getInstance(String message, String evtCommand, Object temp){
        confirm = new Confirm(message, evtCommand, temp);
        if (! confirm.isVisible()){
            confirm.setVisible(true);
        }
        return confirm;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                closeConfirm3(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeConfirm(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("����", 1, 14)); // NOI18N
        jLabel1.setText(message);

        jLabel2.setText("�˸�");

        jButton1.setText("��");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionY(evt);
            }
        });

        jButton2.setText("�̰� ��¥�ƴϾ�");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActionN(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 32, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeConfirm3(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_closeConfirm3
        // TODO add your handling code here:
        confirm.setVisible(false);
    }//GEN-LAST:event_closeConfirm3

    private void closeConfirm(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeConfirm
        // TODO add your handling code here:
        confirm.setVisible(false);
    }//GEN-LAST:event_closeConfirm
    
    
    private void jButton1ActionY(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionY
        if(evtCommand.equals("MenuSelectUpCount")){ //�޴� Ȯ��
            m_action = new Material_Action();
            //���õ� Ƚ�� �ø���
            m_action.LunchSelectUpCount((String)temp);
            m_action.logSelectUpdate((String)temp);

            confirm.setVisible(false);
        } else if(evtCommand.equals("todaySelectReset")){ //���� �޴� �ٽð����� > Y
            //System.out.println("test");
            m_action = new Material_Action();
            int count = m_action.todaySelectReset();
            System.out.println(count);
            confirm.setVisible(false);
            Alert.getInstance("�̹����� ���� ��� ������ �ٷ��� :D");
        }
    }//GEN-LAST:event_jButton1ActionY
    
    
    private void jButtonActionN(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonActionN
        if(evtCommand.equals("MenuSelectUpCount")){ //�޴� Ȯ��x
            m_action = new Material_Action();
            //���õ��� ���� Ƚ�� �ø���
            m_action.LunchNotSelectUpCount((String)temp);

            confirm.setVisible(false);
        } else if(evtCommand.equals("todaySelectReset")){ //���� �޴� �ٽð����� > N
            //m_action = new Material_Action();
            confirm.setVisible(false);
        }
    }//GEN-LAST:event_jButtonActionN

 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
