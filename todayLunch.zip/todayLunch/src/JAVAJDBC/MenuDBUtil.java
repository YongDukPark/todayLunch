package JAVAJDBC;

import TableBean.TODAYLUNCH_MENU_BEAN;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MenuDBUtil{

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement psmt = null;

    //bean ����
    TODAYLUNCH_MENU_BEAN mbean = new TODAYLUNCH_MENU_BEAN();

    public MenuDBUtil(){
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            String url = "jdbc:mariadb://192.168.0.74:3307/youngriabase";
            String id = "youngriadb";
            String pw = "Password0000!";
            System.out.println("testtest DB Connect");

            try {
                con = DriverManager.getConnection(url, id, pw);
                System.out.println("DB���� ��ġ succes");
            } catch (Exception e) {
                System.out.println("DB���� ����ġ discord");
                e.printStackTrace();
            }
        } catch (Exception e) {
            System.out.println("DB���� ����  fail");
            e.printStackTrace();
        }
    }
    // ��������� ������ abst


    //�ܼ� �޴� ����Ʈ �̾ƿ����
    public String[] todayLunchList(){
        String[] menuList = new String[0];
        int i =0;
        ArrayList<String> list = new ArrayList<String>();

        try {
            String sql = "SELECT * FROM TODAYLUNCH_MENU ORDER BY MENU_SELECT_COUNT DESC";

            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            
            //�޴��� �ֱ�
            while(rs.next()){
                //Į�������� �޾Ƽ� �ֱ�
                list.add(rs.getString("MENU_NAME") + "[" + rs.getString("MENU_SELECT_COUNT") + "/" + rs.getString("MENU_CANSLE_COUNT") +"]");
            }

            menuList = new String[list.size()];

            for(i = 0 ; i <= list.size() ; i++){
                menuList[i] = list.get(i);
            }

            System.out.println("********************");
            System.out.println("������ �޴� : " + menuList);
            System.out.println("********************");

        } catch (Exception e) {
            // TODO: handle exception
        }
        

        return menuList;
    }

    //������ �ѷ������ ����Ǵ� method
    //�������� ������
    //230119 �ߺ����� ������ ���� �� �غ�� �޴��� ���� ������ resetCount+1 ��Ű�� �ʱ�ȭ
    public TODAYLUNCH_MENU_BEAN spinSpinWheel(){
        ArrayList<TODAYLUNCH_MENU_BEAN> arraylist = new ArrayList<TODAYLUNCH_MENU_BEAN>();
        String sql1, sql2, sql3 = null;
        String count = null;
        try {
            //row ���� ��������
            sql1 = "SELECT "
                        + "COUNT(*) COUNT "
                        + "FROM TODAYLUNCH_MENU TL_MENU LEFT JOIN "
                    + "(SELECT "
                        + "TL_LOG.MENU_NO , "
                        + "TL_LOG.MENU_NAME "
                        + "FROM TODAYLUNCH_LOG TL_LOG LEFT OUTER JOIN TODAYLUNCH_TODAY_SELECT TL_SELECT "
                        + "ON TL_LOG.MENU_RESET_COUNT = TL_SELECT.MENU_RESET_COUNT "
                        + "WHERE TL_LOG.LAST_START_TIME > SUBTIME(NOW(), TIMEDIFF(NOW(), CAST(DATE(NOW()) AS DATETIME))) "
                        + "AND TL_LOG.MENU_RESET_COUNT = (SELECT MENU_RESET_COUNT FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1) "
                    + ") TL_JOIN "
                        + "ON TL_MENU.MENU_NO = TL_JOIN.MENU_NO "
                        + "where TL_JOIN.MENU_NO IS NULL";
            psmt = con.prepareStatement(sql1);

            rs = psmt.executeQuery();

            while(rs.next()){
                count = rs.getString("COUNT");
            }
            
            //���� row������ update���Ѽ� count+1 ���Ѿ� �޴����� ���´�.
            if(count.equals("0") || count.equals(null)){
                //System.out.println("��������������������������������������������������\n����������������������������������������");
                sql2 = "UPDATE TODAYLUNCH_TODAY_SELECT SET MENU_RESET_COUNT = MENU_RESET_COUNT+1 "
                        + "WHERE LAST_START_TIME = (SELECT LAST_START_TIME FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1)";
                psmt = con.prepareStatement(sql2);
                rs = psmt.executeQuery();
            }
            //����
            //String sql = "SELECT * FROM TODAYLUNCH_MENU";
            
            sql3 = "SELECT "
                        + "TL_MENU.* "
                        + "FROM TODAYLUNCH_MENU TL_MENU LEFT JOIN "
                    + "(SELECT "
                        + "TL_LOG.MENU_NO , "
                        + "TL_LOG.MENU_NAME "
                        + "FROM TODAYLUNCH_LOG TL_LOG LEFT OUTER JOIN TODAYLUNCH_TODAY_SELECT TL_SELECT "
                        + "ON TL_LOG.MENU_RESET_COUNT = TL_SELECT.MENU_RESET_COUNT "
                        + "WHERE TL_LOG.LAST_START_TIME > SUBTIME(NOW(), TIMEDIFF(NOW(), CAST(DATE(NOW()) AS DATETIME))) "
                        + "AND TL_LOG.MENU_RESET_COUNT = (SELECT MENU_RESET_COUNT FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1) "
                    + ") TL_JOIN "
                        + "ON TL_MENU.MENU_NO = TL_JOIN.MENU_NO "
                        + "where TL_JOIN.MENU_NO IS NULL";
            
            psmt = con.prepareStatement(sql3);

            rs = psmt.executeQuery();

            //�޴��� �ֱ�
            while(rs.next()){

                mbean = new TODAYLUNCH_MENU_BEAN();

                mbean.setMENU_NAME(rs.getString("MENU_NAME"));
                mbean.setMENU_STORENAME(rs.getString("MENU_STORENAME"));
                mbean.setMENU_CATE(rs.getString("MENU_CATE"));
                mbean.setMENU_ADDRESS(rs.getString("MENU_ADDRESS"));
                mbean.setMENU_SELECT_COUNT(rs.getInt("MENU_SELECT_COUNT"));
                mbean.setMENU_INTRODUCTION(rs.getString("MENU_INTRODUCTION"));
                mbean.setMENU_NO(rs.getString("MENU_NO"));
                
                //Į�������� �޾Ƽ� �ֱ�
                //Menu = rs.getString("MENU_NAME");
                //System.out.println(rs.getString("MENU_NAME"));

                //Į�������� ArrayList�� �־��ֱ�
                arraylist.add(mbean);
            }
            
            
            mbean = arraylist.get((int)(Math.random() * arraylist.size())+1);

            System.out.println(arraylist.get((int)(Math.random() * arraylist.size())+1).getMENU_NAME());
        } catch (Exception e) {
        }
        return mbean;
    }
    
    public String checkYN(){
        String checkYN = null;
        try {
            String sql = "SELECT MENU_SELECT FROM TODAYLUNCH_TODAY_SELECT WHERE LAST_START_TIME = (SELECT LAST_START_TIME FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1)";

            psmt = con.prepareStatement(sql);
            
            rs = psmt.executeQuery();
            
            while(rs.next()){
                checkYN = rs.getString("MENU_SELECT");
            }
            
        } catch (Exception e) {
        }
        
        return checkYN;
    }
    
    //�������� �����ǽ� ���� �����
    public void insertLog(String MENU_NO, String MENU_NAME){
        String MENU_RESET_COUNT = null;
        try {
            String sql1 = "SELECT MENU_RESET_COUNT FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1";
            psmt = con.prepareStatement(sql1);
            rs = psmt.executeQuery();
            
            while (rs.next()) {
                MENU_RESET_COUNT = rs.getString("MENU_RESET_COUNT");
            }
            
            
            String sql2 = "INSERT INTO TODAYLUNCH_LOG "
                    + "(MENU_NO, MENU_NAME, MENU_RESET_COUNT) "
                    + "VALUES (?,?,?)";

            psmt = con.prepareStatement(sql2);
            
            psmt.setString(1, MENU_NO);
            psmt.setString(2, MENU_NAME);
            psmt.setString(3, MENU_RESET_COUNT);
            
            rs = psmt.executeQuery();
            
        } catch (Exception e) {
        }
    }
    public void upCount(String MENU_NO, String MENU_NAME){
        try {
            String sql = "UPDATE TODAYLUNCH_TODAY_SELECT SET"
                    + " MENU_NO = ? , MENU_NAME = ? , MENU_SELECT_TOTALCOUNT = MENU_SELECT_TOTALCOUNT+1"
                    + " where LAST_START_TIME = (SELECT LAST_START_TIME FROM TODAYLUNCH_TODAY_SELECT ORDER BY LAST_START_TIME DESC LIMIT 1)";
            
            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, MENU_NO);
            psmt.setString(2, MENU_NAME);
            
            rs = psmt.executeQuery();
            
        } catch (Exception e) {
        }
    }
    
    
    //insert �����
    public int menuInsert(TODAYLUNCH_MENU_BEAN mbean){
        try {
            String sql = "Insert into TODAYLUNCH_MENU"
                    + "(MENU_NO, MENU_NAME,MENU_STORENAME,MENU_ADDRESS,MENU_CATE,MENU_INTRODUCTION) values "
                    + "(NEXTVAL(TODAYLUNCH_MENU_SEQ),?,?,?,?,?)";

            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, mbean.getMENU_NAME());
            psmt.setString(2,mbean.getMENU_STORENAME());
            psmt.setString(3,mbean.getMENU_CATE());
            psmt.setString(4,mbean.getMENU_ADDRESS());
            psmt.setString(5,mbean.getMENU_INTRODUCTION());
            
            rs = psmt.executeQuery();
            System.out.println("count : " + rs);
            
        } catch (Exception e) {
        }
        
        
        return 0;
    }
    
    public void menuDelete(String MENU_NO){
        try {
            String sql = "DELETE FROM TODAYLUNCH_MENU WHERE MENU_NO = ?";

            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, MENU_NO);
            
            rs = psmt.executeQuery();
            
        } catch (Exception e) {
        }
    }
    
    //Menu insert
    public void insertRow(TODAYLUNCH_MENU_BEAN bean){
        try{
            String sql = "INSERT INTO TODAYLUNCH_MENU (MENU_NO , MENU_NAME, MENU_STORENAME, MENU_CATE, MENU_INTRODUCTION, MENU_ADDRESS) VALUES "
                    + "(NEXTVAL(TODAYLUNCH_MENU_SEQ),?,?,?,?,?)";
            
            psmt = con.prepareStatement(sql);
            System.out.println("test t t t �ķֱ� �ķֱ� " + bean.getMENU_NAME());
            psmt.setString(1, bean.getMENU_NAME());
            System.out.println("test t t t �ķֱ� �ķֱ� " + bean.getMENU_STORENAME());
            psmt.setString(2, bean.getMENU_STORENAME());
            System.out.println("test t t t �ķֱ� �ķֱ� " + bean.getMENU_CATE());
            psmt.setString(3, bean.getMENU_CATE());
            System.out.println("test t t t �ķֱ� �ķֱ� " + bean.getMENU_INTRODUCTION());
            psmt.setString(4, bean.getMENU_INTRODUCTION());
            System.out.println("test t t t �ķֱ� �ķֱ� " + bean.getMENU_ADDRESS());
            psmt.setString(5, bean.getMENU_ADDRESS());
            psmt.executeUpdate();
        }catch(Exception e){
            System.err.println(e);
        }
    }
    
    //Menu ����
    public void updateRow(TODAYLUNCH_MENU_BEAN bean){
        try{
            String sql = "UPDATE TODAYLUNCH_MENU SET MENU_NAME = ?, MENU_STORENAME = ?, MENU_CATE = ?, MENU_INTRODUCTION = ?, MENU_ADDRESS = ? "
                    + "WHERE MENU_NO = ?";
            
            psmt = con.prepareStatement(sql);
            psmt.setString(1, bean.getMENU_NAME());
            psmt.setString(2, bean.getMENU_STORENAME());
            psmt.setString(3, bean.getMENU_CATE());
            psmt.setString(4, bean.getMENU_INTRODUCTION());
            psmt.setString(5, bean.getMENU_ADDRESS());
            psmt.setString(6, bean.getMENU_NO());
            psmt.executeUpdate();
        }catch(Exception e){
            
        }
    }
    
    
}