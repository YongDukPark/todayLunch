/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package todaylunch;

import JAVAJDBC.MenuDBUtil;
import TableBean.TODAYLUNCH_MENU_BEAN;
import com.arisystem.beans.datawizard.DWWhereCondition;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
//import java.util.Vector;

public class MENUUPDATE extends javax.swing.JFrame {

    private static MENUUPDATE menuCheck;
    
    //�ʿ��� ģ����
    
    //JDBC�뵵
    MenuDBUtil MenuDBUtil = new MenuDBUtil();
    //select count ��ü �����Ҷ� length �˱�뵵
    int rowCount = 0;
    //delete�� Ƚ���� �����ؼ� rowCount�� �������� �뵵
    int deleteCount = 0;
    //üũ�ڽ� ���� ����� temp
    ArrayList<Object> arraylist = new ArrayList<>();
    //üũ�ڽ� delete�� ��ġ���� index ����� �ֳ��ϸ� �̷��� row������� �־��ְ� �������� ������ ����� ������ row��ġ������ ȥ���� �Ȼ����.
    ArrayList<Object> deleteListIndex = new ArrayList<>();
    //������ ������ Menu_No����
    ArrayList<Object> deletelist = new ArrayList<>();
    
    //��ü ���� ���뵵
    TODAYLUNCH_MENU_BEAN bean;
    
    //��ü�� keyValue���·� �����ϱ� ���� hashMap
    Map<String, TODAYLUNCH_MENU_BEAN> map = new HashMap<String, TODAYLUNCH_MENU_BEAN>();
    
    //����� ��ü�� ���� ����뵵
    ArrayList<TODAYLUNCH_MENU_BEAN> changeRow = new ArrayList<>();
    
    private MENUUPDATE() {
        initComponents();
        
        refresh();
    }
    
    public static MENUUPDATE getInstance(){
        menuCheck = new MENUUPDATE();
        if(! menuCheck.isVisible()){
            menuCheck.setVisible(true);
        }
        return menuCheck;
    }
    
    public void refresh(){
        Vector params = new Vector();
        DWWhereCondition SearchSelect;
        
        String[] testttt = jTextField1.getText().replaceAll(" ", "").split("");
        String Query = " 1 = 1 AND( 1 = 1 ";
        
        String coulmnsType = null;
        try{
            if(!jTextField1.getText().equals("") && jComboBox1.getSelectedIndex() != 0){ //�˻����� �����ϰ� �˻��������
                params.clear();
                
                if(jComboBox1.getItemAt(jComboBox1.getSelectedIndex()).equals("�޴���")){
                    coulmnsType = "MENU_NAME";
                } else if (jComboBox1.getItemAt(jComboBox1.getSelectedIndex()).equals("���Ը�")){
                    coulmnsType = "MENU_STORENAME";
                } else if (jComboBox1.getItemAt(jComboBox1.getSelectedIndex()).equals("ī�װ���")){
                    coulmnsType = "MENU_CATE";
                } else if (jComboBox1.getItemAt(jComboBox1.getSelectedIndex()).equals("�ּ�")){
                    coulmnsType = "MENU_ADDRESS";
                }
                for(int i = 0 ; i < testttt.length ; i++){
                    params.add("%"+testttt[i]+"%");
                }
                for(int i = 0 ; i < testttt.length ; i++){
                    Query += "AND "+coulmnsType+" LIKE ? ";
                }
                Query += ")";
                
                SearchSelect = new DWWhereCondition(Query, params);

                dWCombineTable1.setWhereContition(SearchSelect);
            } else if(jTextField1.getText().equals("") || jComboBox1.getSelectedIndex() == 0) { //�˻����� �������
                params.clear();
                jTextField1.setText("");
                params.add("%"+""+"%");
                SearchSelect = new DWWhereCondition("MENU_NAME like ?", params);

                dWCombineTable1.setWhereContition(SearchSelect);
            }
            
            dWCombineTable1.setDataSource("MariaDB_Youngria");
            dWCombineTable1.setOrderBy("MENU_SELECT_COUNT DESC");
            dWCombineTable1.select("http", "192.168.0.20", 8080);
            this.rowCount = dWCombineTable1.selectTotalRowCount("http", "192.168.0.20", 8080);
            
        }catch(Exception e){
            System.err.println(e);
        } 
    }
    
    public void clearExit(){
        rowCount = 0;
        deleteCount = 0;
        arraylist.clear();
        deleteListIndex.clear();
        deletelist.clear();
        map.clear();
        changeRow.clear();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dWCombineTable1 = new com.arisystem.beans.combinetable.DWCombineTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btn_SearchSelect = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();

        dWCombineTable1.setBodyRenderer(new com.arisystem.beans.combinetable.BodyRenderer( new com.arisystem.beans.combinetable.BodyCombineCell[] {
            new com.arisystem.beans.combinetable.BodyCombineCell("__ROW_STATUS__", new com.arisystem.beans.combinetable.CellInfo(0,0), new com.arisystem.beans.combinetable.CellInfo(0,0), null, com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.datawizard.DWStatusCombineCellEditor", "com.arisystem.beans.datawizard.DWStatusCombineCellPainter",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_NO", new com.arisystem.beans.combinetable.CellInfo(1,0), new com.arisystem.beans.combinetable.CellInfo(1,0), "new", com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_NAME", new com.arisystem.beans.combinetable.CellInfo(2,0), new com.arisystem.beans.combinetable.CellInfo(2,0), null, com.arisystem.beans.combinetable.CombineCell.LEFT_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.combinetable.StringCombineCellEditor", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_STORENAME", new com.arisystem.beans.combinetable.CellInfo(3,0), new com.arisystem.beans.combinetable.CellInfo(3,0), null, com.arisystem.beans.combinetable.CombineCell.LEFT_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.combinetable.StringCombineCellEditor", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_ADDRESS", new com.arisystem.beans.combinetable.CellInfo(4,0), new com.arisystem.beans.combinetable.CellInfo(4,0), null, com.arisystem.beans.combinetable.CombineCell.LEFT_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.combinetable.StringCombineCellEditor", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_CATE", new com.arisystem.beans.combinetable.CellInfo(7,0), new com.arisystem.beans.combinetable.CellInfo(7,0), null, com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.combinetable.StringCombineCellEditor", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_INTRODUCTION", new com.arisystem.beans.combinetable.CellInfo(8,0), new com.arisystem.beans.combinetable.CellInfo(8,0), null, com.arisystem.beans.combinetable.CombineCell.LEFT_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "com.arisystem.beans.combinetable.StringCombineCellEditor", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_UPDATE_DAY", new com.arisystem.beans.combinetable.CellInfo(9,0), new com.arisystem.beans.combinetable.CellInfo(9,0), null, com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "", "com.arisystem.beans.combinetable.DateCombineCellPainter",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_SELECT_COUNT", new com.arisystem.beans.combinetable.CellInfo(5,0), new com.arisystem.beans.combinetable.CellInfo(5,0), null, com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "", "",null),
            new com.arisystem.beans.combinetable.BodyCombineCell("MENU_CANSLE_COUNT", new com.arisystem.beans.combinetable.CellInfo(6,0), new com.arisystem.beans.combinetable.CellInfo(6,0), null, com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT, com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null, null, null, "", "com.arisystem.beans.combinetable.NumberCombineCellPainter",null),
        }));
        dWCombineTable1.setCellCount(10);
        dWCombineTable1.setCellWidths(new int[] {24, 26, 158, 97, 89, 34, 32, 39, 207, 88});
        dWCombineTable1.setErdObjectLocations(new com.arisystem.beans.datawizard.DWErdObjectLocation[]{new com.arisystem.beans.datawizard.DWErdObjectLocation("TODAYLUNCH_MENU",30,0)});
        dWCombineTable1.setGroupBy("");
        dWCombineTable1.setHeaderRenderer(new com.arisystem.beans.combinetable.HeaderRenderer( new com.arisystem.beans.combinetable.HeaderCombineCell[] {
            new com.arisystem.beans.combinetable.HeaderCombineCell("__ROW_STATUS__",new com.arisystem.beans.combinetable.CellInfo(0,0),new com.arisystem.beans.combinetable.CellInfo(0,0),null,com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"com.arisystem.beans.combinetable.CheckBoxCombineCellPainter",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_NO",new com.arisystem.beans.combinetable.CellInfo(1,0),new com.arisystem.beans.combinetable.CellInfo(1,0),"��ȣ",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_NAME",new com.arisystem.beans.combinetable.CellInfo(2,0),new com.arisystem.beans.combinetable.CellInfo(2,0),"�޴���",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_STORENAME",new com.arisystem.beans.combinetable.CellInfo(3,0),new com.arisystem.beans.combinetable.CellInfo(3,0),"���Ը�",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_SELECT_COUNT",new com.arisystem.beans.combinetable.CellInfo(5,0),new com.arisystem.beans.combinetable.CellInfo(5,0),"����",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_CATE",new com.arisystem.beans.combinetable.CellInfo(7,0),new com.arisystem.beans.combinetable.CellInfo(7,0),"ī��",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_UPDATE_DAY",new com.arisystem.beans.combinetable.CellInfo(9,0),new com.arisystem.beans.combinetable.CellInfo(9,0),"������¥",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_CANSLE_COUNT",new com.arisystem.beans.combinetable.CellInfo(6,0),new com.arisystem.beans.combinetable.CellInfo(6,0),"����",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_INTRODUCTION",new com.arisystem.beans.combinetable.CellInfo(8,0),new com.arisystem.beans.combinetable.CellInfo(8,0),"������",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
            new com.arisystem.beans.combinetable.HeaderCombineCell("MENU_ADDRESS",new com.arisystem.beans.combinetable.CellInfo(4,0),new com.arisystem.beans.combinetable.CellInfo(4,0),"��ġ",com.arisystem.beans.combinetable.CombineCell.CENTER_ALIGNMENT,com.arisystem.beans.combinetable.CombineCell.HORIZONTAL,null,null,null,"",null),
        }));
        dWCombineTable1.setJoinConditions(new com.arisystem.beans.datawizard.DWJoinCondition[] {
            new com.arisystem.beans.datawizard.DWNotJoinCondition(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"))});
    dWCombineTable1.setMainTable(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"));
    dWCombineTable1.setOrderBy("");
    dWCombineTable1.setSelectFieldObjects(new com.arisystem.beans.datawizard.DWAliasFieldObject[]{
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_NO",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_NO") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_NAME",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_NAME") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_STORENAME",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_STORENAME") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_SELECT_COUNT",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_SELECT_COUNT") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_CATE",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_CATE") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_UPDATE_DAY",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_UPDATE_DAY") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_CANSLE_COUNT",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_CANSLE_COUNT") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_INTRODUCTION",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_INTRODUCTION") ,
        new com.arisystem.beans.datawizard.DWAliasFieldObject(new com.arisystem.beans.datawizard.DWTable("null","TODAYLUNCH_MENU","TODAYLUNCH_MENU"),"MENU_ADDRESS",com.arisystem.beans.datawizard.DWFieldObject.DATA_FIELD_LARGE_NORMAL,"MENU_ADDRESS") });
dWCombineTable1.setWhereContition(new com.arisystem.beans.datawizard.DWWhereCondition(""));
dWCombineTable1.addTableBodyListener(new com.arisystem.beans.combinetable.TableBodyListener() {
    public void combineTableBodyActionEditCell(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyBeforeEditCell(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyBeforePaintCell(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyEnteringRow(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyValueChanged(com.arisystem.beans.combinetable.TableBodyEvent evt) {
        tableBodyValueChange(evt);
    }
    public void combineTableHorScrolled(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableVerScrolled(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyMouseClick(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyMouseEnter(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodyMouseExit(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    public void combineTableBodySelectedRow(com.arisystem.beans.combinetable.TableBodyEvent evt) {
    }
    });
    dWCombineTable1.addTableHeaderListener(new com.arisystem.beans.combinetable.TableHeaderListener() {
        public void combineTableHeaderMouseClick(com.arisystem.beans.combinetable.TableHeaderEvent evt) {
            tableHeaderMouseClick(evt);
        }
        public void combineTableHeaderMouseEnter(com.arisystem.beans.combinetable.TableHeaderEvent evt) {
        }
        public void combineTableHeaderMouseExit(com.arisystem.beans.combinetable.TableHeaderEvent evt) {
        }
        public void combineTableHeaderBeforePaintCell(com.arisystem.beans.combinetable.TableHeaderEvent evt) {
        }
    });

    jButton1.setText("�޴� �߰�");
    jButton1.setActionCommand("MENU_ADD");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            buttonClickEvent(evt);
        }
    });

    jButton2.setText("����");
    jButton2.setActionCommand("MENU_DELETE");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            buttonClickEvent(evt);
        }
    });

    jButton3.setText("����");
    jButton3.setActionCommand("MENU_SAVE");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            buttonClickEvent(evt);
        }
    });

    btn_SearchSelect.setText("�˻�");
    btn_SearchSelect.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            buttonClickEvent(evt);
        }
    });

    jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "����(�⺻)", "�޴���", "���Ը�", "ī�װ���", "�ּ�" }));

    jTextField1.setToolTipText("�˻��� �Է�");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(dWCombineTable1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(btn_SearchSelect)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 426, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap())
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(16, 16, 16)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton1)
                .addComponent(jButton2)
                .addComponent(jButton3)
                .addComponent(btn_SearchSelect)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(dWCombineTable1, javax.swing.GroupLayout.DEFAULT_SIZE, 653, Short.MAX_VALUE)
            .addContainerGap())
    );

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonClickEvent(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClickEvent
        if(evt.getActionCommand().equals("MENU_ADD")) {
            dWCombineTable1.addRow();
            this.rowCount++;
        } else if (evt.getActionCommand().equals("MENU_DELETE")) {
            //������������ ����
            Collections.sort(deleteListIndex, Collections.reverseOrder());
            for(int i = 0 ; i < arraylist.size() ; i++){
                //row���� ����
                dWCombineTable1.removeRow((int)deleteListIndex.get(i));
                System.out.println("�����ҳ༮ : " + arraylist.get(i));
                System.out.println("������Index : " + deleteListIndex.get(i));
                
                //������ value������ ��Ƴ��°�
                deletelist.add(arraylist.get(i));
                deleteCount++;
            }
            System.out.println(deleteCount + "���� �޴��� �����Ǿ����ϴ�.");
            
            //rowcount �������� �����Ű�� �������� ��Ż���� �˾ƾ� ��ü ����Ʈ�� �Ҽ����� �����Ű�� ����
            //this.rowCount = ;
            //System.out.println("rowcount" + dWCombineTable1.getRowCount());
            this.rowCount = rowCount-deleteCount;
            
            
            //�ʱ�ȭ �۾�
            deleteCount = 0;
            arraylist.clear();
            deleteListIndex.clear();
            //clearExit();
        } else if (evt.getActionCommand().equals("MENU_SAVE")) {
            //map �ֵ� �����ͼ� ArrayList�� ��������
            for( String key : map.keySet() ) {
                changeRow.add(map.get(key));
            }

            //JDBC ���·� ����
            //�ο��� ���� ������� insert ���� ������ update������ changeRow�� ���̸�ŭ �ݺ���Ų��.
            //keyvalue������ �����ؾ߰ڰ� HashMap ���·� Ű������ �װ� �ְ� ��ü ���·� �־�߰ڱ���
            //�����·� �־������
            //MenuDBUtil = new MenuDBUtil();
            for(int i = 0 ; i < changeRow.size() ; i++){
                System.out.println(changeRow.get(i).getMENU_NO());

                if(changeRow.get(i).getMENU_NO().contains("new")){
                    MenuDBUtil.insertRow(changeRow.get(i));
                } else {
                    MenuDBUtil.updateRow(changeRow.get(i));
                }
            }
            //���� ����
//            for(int i = 0 ; i < deletelist.size() ; i++){
//                if(deletelist.get(i) !=  null){
//                    continue;
//                } else {
//                    DataJDBC.Delete_Menu((String)deletelist.get(i));
//                }
//            }
            //select + �ʱ�ȭ�۾�
            clearExit();
            refresh();
            
//            changeRow.clear();
//            map.clear();
//            
//            //���� ���� �ʱ�ȭ �۾�
//            arraylist.clear();
//            deletelist.clear();
//            deleteListIndex.clear();
//            deleteCount = 0;
        } else if (evt.getSource() == btn_SearchSelect) {
            clearExit();
            refresh();
        }
    }//GEN-LAST:event_buttonClickEvent
    
    //���̺� ��� ���� ����� ���������� checkbox�뵵
    private void tableHeaderMouseClick(com.arisystem.beans.combinetable.TableHeaderEvent evt) {//GEN-FIRST:event_tableHeaderMouseClick
        if(dWCombineTable1.getHeaderTitleValue("__ROW_STATUS__").equals(true)){
            arraylist.clear();
            
            //230125 �߰��� ���� �ε��� ������ �޾� ����� ����
            deleteListIndex.clear();
        } else {
            for(int i = 0 ; i < rowCount ; i++){
                if(String.valueOf(dWCombineTable1.getValue(i, "__ROW_STATUS__")).contains("false")){
                    if(arraylist.contains(dWCombineTable1.getValue(i, "MENU_NO"))){
                        
                    }else {
                        arraylist.add(dWCombineTable1.getValue(i, "MENU_NO"));
                        //230125 �߰��� ���� �ε��� ������ �޾� ����� ����
                        deleteListIndex.add(i);
                    }
                }
            }
        }
        
    }//GEN-LAST:event_tableHeaderMouseClick

    //���̺� �ٵ�κ� ���� ����� ����
    private void tableBodyValueChange(com.arisystem.beans.combinetable.TableBodyEvent evt) {//GEN-FIRST:event_tableBodyValueChange
        //üũ�ڽ� ����
        if(String.valueOf(dWCombineTable1.getValue(evt.getRowIndex(), evt.getCombineCellName())).contains("false")){
            arraylist.remove(dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO"));
            
            //230125 �߰��� ���� �ε��� ������ �޾� ����� ����
            deleteListIndex.remove((Object)evt.getRowIndex());
        } else {
            arraylist.add(dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO"));
            
            //230125 �߰��� ���� �ε��� ������ �޾� ����� ����
            deleteListIndex.add(evt.getRowIndex());
        }
        //üũ�ڽ� ���� ��
        
        //���ο� Row ������ ���а� �뵵
        String newRow = "new"+evt.getRowIndex();
        
        //��ü���� ���뵵
        bean = new TODAYLUNCH_MENU_BEAN();
        
        //������ȣ null�ϰ�� newRow+index�ѹ� hashMap�뵵�� ������ ���Ƿ� ����
        if(dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO") != null){
            bean.setMENU_NO((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO"));
        } else {
            bean.setMENU_NO(newRow);
        }
        bean.setMENU_NAME((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NAME"));
        bean.setMENU_STORENAME((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_STORENAME"));
        bean.setMENU_ADDRESS((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_ADDRESS"));
        bean.setMENU_CATE((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_CATE"));
        bean.setMENU_INTRODUCTION((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_INTRODUCTION"));
        
        //��ü���� HashMap�� Key Value ���·� ����ֱ�
        if(dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO") != null){
            map.put((String)dWCombineTable1.getValue(evt.getRowIndex(), "MENU_NO"), bean);
        } else {
            map.put(newRow, bean);
        }
        System.out.println("�� ���� : " + map.size());
    }//GEN-LAST:event_tableBodyValueChange

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MENUUPDATE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MENUUPDATE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MENUUPDATE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MENUUPDATE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MENUUPDATE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_SearchSelect;
    private com.arisystem.beans.combinetable.DWCombineTable dWCombineTable1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
